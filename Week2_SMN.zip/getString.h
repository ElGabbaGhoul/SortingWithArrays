//
// Created by scnid on 4/15/2024.
//
#ifndef GETSTRING_H
#define GETSTRING_H

#include <string>

// Get string from user input

std::string getString();

#endif //GETSTRING_H
